k = 1/4;
m = 1/2;


%%Question 2_1
t_x1 = -m:0.01:0;
t_h1 = 0:0.01:30;

x1 = e.^(-k*t_x1);
h1 = k;


t_conv1_1 = -m:0.01:0;
t_conv1_2 = 0:0.01:30;

conv1_1 = -e.^(-k*t_conv1_1) + e.^(k * m); 
conv1_2 = e.^(k * m) - 1;

figure('Name', 'Question 2_1');
subplot (2,2,1);
plot (t_x1, x1);
title ('x(t)');
subplot (2,2,2);
plot (t_h1, h1);
title('h(t)');
subplot (2,2,3);
plot (t_conv1_1, conv1_1);
hold on;
plot (t_conv1_2, conv1_2);
title ('x(t) * h(t)');



%%Question 2_2
t_x2 = -1:0.01:k;
t_h2 = -1:0.01:k;

x2 = t_x2;
h2 = e.^(-m * t_h2.^(2));


t_conv2 = -1:0.01:k;

conv2 = e.^(-m * t_conv2 .^ (2)) * sqrt(pi / m) * ((e.^(-t_conv2) / t_conv2) + (e.^(k * t_conv2) / t_conv2)); 

figure('Name', 'Question 2_2');
subplot (2,2,1);
plot (t_x2, x2);
title ('x(t)');
subplot (2,2,2);
plot (t_h2, h2);
title('h(t)');
subplot (2,2,3);
plot (t_conv2, conv2);

title ('x(t) * h(t)');




%%Question 2_3
t_x3 = -2:0.01:1;
t_h3 = -m:0.01:k;

x3 = t_x3;
h3 = 3;


t_conv3_1 = -2:0.01:-m;
t_conv3_2 = -m:0.01:k;
t_conv3_3 = k:0.01:1;

conv3_1 = 3 * (t_conv3_1 + 2); 
conv3_2 = 0;
conv3_3 = 9 / 4;

figure('Name', 'Question 2_3');
subplot (2,2,1);
plot (t_x3, x3);
title ('x(t)');
subplot (2,2,2);
plot (t_h3, h3);
title('h(t)');
subplot (2,2,3);
plot (t_conv3_1, conv3_1);
hold on;
plot (t_conv3_2, conv3_2);
hold on;
plot (t_conv3_3, conv3_3);
title ('x(t) * h(t)');



%%Question 2_4
t_x4 = -m * pi:0.01:m * pi;
t_h4 = -1:0.01:1;
x4 = k;
h4 = sin(k * t_h4);


t_conv4_1 = m * pi:0.01:30;
conv4_1 = cos(k * (t_conv4_1 - m)) - cos(k * (t_conv4_1 + m)); 


figure('Name', 'Question 2_4');
subplot (2,2,1);
plot (t_x4, x4);
title ('x(t)');
subplot (2,2,2);
plot (t_h4, h4);
title('h(t)');
subplot (2,2,3);
plot (t_conv4_1, conv4_1);
title ('x(t) * h(t)');


%%Question 2_5
t_x5 = -m:0.01:30;
t_h5 = k:0.01:30;
x5 = k * t_x5;
h5 = e.^(-m * t_h5);

%%x1 = e.^(-k*t_x1);

t_conv5_1 = -m:0.01:k;
conv5_1 = k * (((e.^(-m * (t_conv5_1 - k))) / (m * t_conv5_1)) -  (e.^(-m * (t_conv5_1 + m)) / (m * t_conv5_1))); 


figure('Name', 'Question 2_5');
subplot (2,2,1);
plot (t_x5, x5);
title ('x(t)');
subplot (2,2,2);
plot (t_h5, h5);
title('h(t)');
subplot (2,2,3);
plot (t_conv5_1, conv5_1);
title ('x(t) * h(t)');

